# Icon Theme Profile

# The FreeDesktop Suru icon set is designed and developed by:
# - Sam Hewitt <sam@snwh.org>
# - under GPL3

# The original Suru icon set and concept was created by:
# - Matthieu James
# - Canonical Design Team

# Based on the Suru plus Ubuntu theme

# All new modifications was created by: 
# - Adhe <adhemarks@gmail.com>
flatpak install --system com.discordapp.Discord -y
flatpak install --system com.obsproject.Studio -y
flatpak install --system com.prusa3d.PrusaSlicer -y
flatpak install --system io.github.Figma_Linux.figma_linux -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
